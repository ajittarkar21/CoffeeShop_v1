package com.coffeeshop.service;

import com.coffeeshop.model.Addons;
import com.coffeeshop.model.CustomerOrder;
import com.coffeeshop.model.CustomerOrderItem;
import com.coffeeshop.model.StampCard;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class BillProcessingService {
	public void calculateBillToBePaid(CustomerOrder customerOrder) {
		Double orderTotal = 0.0;
		StampCard stampCard = customerOrder.getStampCard();
		Integer stampCardOpening = stampCard.getBeverageOrderedCount();
		Optional<Addons> cheapestAddon = null;
		for (CustomerOrderItem orderItem : customerOrder.getOrderItemList()) {
			if (orderItem.isBeverage()) {
				stampCard.setBeverageOrderedCount(stampCard.getBeverageOrderedCount() + 1);
			}
			if ((stampCard.getBeverageOrderedCount()) == 5) {
				stampCard.setBeverageOrderedCount(0);
				orderItem.setPrice(0.0);
			}
			Double itemPrice = orderItem.getPrice();
			Double addonsTotal = 0.0;
			List<Addons> addonsList = orderItem.getAddons();

			if (!(addonsList == null || addonsList.isEmpty())) {
				addonsTotal = addonsList.stream().mapToDouble(Addons::getPrice).sum();
				itemPrice += addonsTotal;
			}
			orderItem.setPrice(itemPrice);
			orderTotal += itemPrice;

		}
		if (customerOrder.getBeverageCount() >= 1 && customerOrder.getSnacksCount() >= 1) {
			cheapestAddon = getCheapestAddonFromOrders(customerOrder);
			if (cheapestAddon.isPresent()) {
				orderTotal -= cheapestAddon.get().getPrice();
			}
			System.out.println("CHEAPEST - " + cheapestAddon.get());
		}
		billPrint(customerOrder, orderTotal, cheapestAddon, stampCardOpening, stampCard);
	}

	public void billPrint(CustomerOrder customerOrder, Double orderTotal, Optional<Addons> cheapestAddOn,
			Integer stampCardOpenBal, StampCard card) {
		System.out.println("---------------------------------------------");
		System.out.println("         Coffee Shop Bill                    ");
		System.out.println("---------------------------------------------");
		customerOrder.getOrderItemList().forEach(eachItem -> {
			System.out.printf("%s: %.2f CHF%n", eachItem.getItemPrintName(), eachItem.getPrice());
		});
		System.out.println("---------------------------------------------");
		System.out.printf("Total: %.2f CHF%n", orderTotal);
		System.out.println("---------------------------------------------");
		if (cheapestAddOn.isPresent()) {
			Addons extra = cheapestAddOn.get();
			System.out.println("Discounted Addons:");
			System.out.printf("%s: %.2f CHF%n", extra.getName(), extra.getPrice());
			System.out.println();
			System.out.println("Stamp Cards Details:");
			System.out.println("Opening Points : " + stampCardOpenBal);
			System.out.println("Closing Points : " + card.getBeverageOrderedCount());
			System.out.println("---------------------------------------------");
		}
	}

	// Helper method to check if there's any snack in the order list
	private boolean hasSnack(List<CustomerOrderItem> orderItemList) {
		for (CustomerOrderItem orderItem : orderItemList) {
			if (!orderItem.isBeverage()) {
				return true;
			}
		}
		return false;
	}

	// Helper method to get the price of the cheapest addon
	public Optional<Addons> getCheapestAddonFromOrders(CustomerOrder order) {
		Optional<Addons> cheapestAddon = Optional.of(new Addons("DUMMY", Double.MAX_VALUE));
		for (CustomerOrderItem orderItem : order.getOrderItemList()) {
			List<Addons> addonsList = orderItem.getAddons();
			Optional<Addons> minAddon = addonsList.stream().min(Comparator.comparingDouble(Addons::getPrice));
			if (minAddon.isPresent() && (cheapestAddon.get().getPrice() > minAddon.get().getPrice())) {
				cheapestAddon = minAddon;
			}
		}
		return (cheapestAddon.get().getPrice() == Double.MAX_VALUE) ? Optional.empty() : cheapestAddon;
	}

}
