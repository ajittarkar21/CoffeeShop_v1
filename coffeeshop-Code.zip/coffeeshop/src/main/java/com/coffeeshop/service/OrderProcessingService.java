package com.coffeeshop.service;

import com.coffeeshop.exceptions.CoffeeShopException;
import com.coffeeshop.model.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class OrderProcessingService {
	private final List<String> BEVERAGE_ITEMS_LIST = Arrays.asList("coffee", "juice");
	private final List<String> SNACKS_ITEMS_LIST = Arrays.asList("roll");

	public CustomerOrder processOrderRequest(List<String> requestOrderList) throws CoffeeShopException {
		System.out.println("Processing Customer order");
		List<CustomerOrderItem> customerOrderItemList = new ArrayList<>();
		int beverageCount = 0;
		int snacksCount = 0;
		boolean isFirst = true;
		StampCard stampCard = null;
		for (String requestOrderItem : requestOrderList) {
			if (isFirst) {
				try {
					stampCard = new StampCard(Integer.parseInt(requestOrderItem));
				} catch (Exception ex) {
					throw new CoffeeShopException("Bad Request, StampCard value is Mandatory !!!");
				}
				isFirst = false;
			}
			String itemName;
			String extra = null;
			double extraCost = 0;

			// Item name and extra
			if (requestOrderItem.contains("with")) {
				String[] parts = requestOrderItem.split(Constants.DELIMETER);
				itemName = parts[0].trim();
				extra = parts[1].trim();
			} else {
				itemName = requestOrderItem.trim();
			}
			// item cost
			Double itemCost = Constants.MENU.get(itemName);
			// populating an order list
			if (itemName != null && itemCost != null) {
				List<Addons> addonsList = new ArrayList<>();

				CustomerOrderItem customerOrderItem = new CustomerOrderItem();
				customerOrderItem.setItemPrintName(requestOrderItem);
				customerOrderItem.setName(itemName);
				customerOrderItem.setPrice(itemCost);
				customerOrderItem.setBeverage(false);
				customerOrderItem.setSnacks(false);
				customerOrderItem.setAddonsList(addonsList);

				if (BEVERAGE_ITEMS_LIST.stream().anyMatch(i -> itemName.toLowerCase().contains(i.toLowerCase()))) {
					beverageCount++;
					customerOrderItem.setBeverage(true);
				}

				if (SNACKS_ITEMS_LIST.stream().anyMatch(i -> itemName.toLowerCase().contains(i.toLowerCase()))) {
					snacksCount++;
					customerOrderItem.setSnacks(true);
				}

				if (extra != null) {
					extraCost = Constants.ADDONS.get(extra);
					customerOrderItem.getAddons().add(new Addons(extra, extraCost));
				}
				customerOrderItemList.add(customerOrderItem);
			}
		}
		return (new CustomerOrder(customerOrderItemList, beverageCount, snacksCount, stampCard));
	}
}
