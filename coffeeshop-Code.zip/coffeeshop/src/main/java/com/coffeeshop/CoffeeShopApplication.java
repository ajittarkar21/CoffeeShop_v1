package com.coffeeshop;

import com.coffeeshop.exceptions.CoffeeShopException;
import com.coffeeshop.service.BillProcessingService;
import com.coffeeshop.service.OrderProcessingService;
import com.coffeeshop.stubs.CoffeeShopClientStub;

import java.util.Arrays;

public class CoffeeShopApplication {
	public static void main(String[] args) {
//        String[] order = {

		// client request payload
		// Assuming 0th index of the order as stamp card entry from previous orders
		String[] order = { "4", "large coffee with extra milk", "large coffee with extra milk", "bacon roll" };

		// Objects Initialization
		OrderProcessingService orderService = new OrderProcessingService();
		BillProcessingService billService = new BillProcessingService();
		CoffeeShopClientStub coffeeShopClientStub = new CoffeeShopClientStub(orderService, billService);

		try {
			// application stub simulates the coffee shop operations
			coffeeShopClientStub.performOrderOperations(Arrays.asList(order));
		} catch (CoffeeShopException e) {
			System.out.println("CoffeeShop ERROR - " + e.getMessage());
		}
	}
}
