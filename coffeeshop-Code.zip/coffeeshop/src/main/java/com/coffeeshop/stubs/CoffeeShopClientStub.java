package com.coffeeshop.stubs;

import com.coffeeshop.exceptions.CoffeeShopException;
import com.coffeeshop.model.CustomerOrder;
import com.coffeeshop.model.StampCard;
import com.coffeeshop.service.BillProcessingService;
import com.coffeeshop.service.OrderProcessingService;

import java.util.List;

public class CoffeeShopClientStub {
    OrderProcessingService orderProcessingService;
    BillProcessingService billProcessingService;
    StampCard stampCard;

    public CoffeeShopClientStub(OrderProcessingService orderService, BillProcessingService billService) {
        this.orderProcessingService = orderService;
        this.billProcessingService = billService;
    }

    public void performOrderOperations(List<String> orderPlaced) throws CoffeeShopException {
        System.out.println("Order request received : " + orderPlaced);

        // process order request
        CustomerOrder customerOrder = orderProcessingService.processOrderRequest(orderPlaced);
        System.out.println("Processed Order: " + customerOrder);

        // process bills
        billProcessingService.calculateBillToBePaid(customerOrder);

    }
}
