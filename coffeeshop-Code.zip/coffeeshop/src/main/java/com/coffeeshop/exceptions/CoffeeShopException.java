package com.coffeeshop.exceptions;

public class CoffeeShopException extends Exception {
	public CoffeeShopException(String message) {
		super(message);
	}
}
