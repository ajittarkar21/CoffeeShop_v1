package com.coffeeshop.model;

import java.util.Map;

public class Constants {
	public static final Map<String, Double> MENU = Map.of("small coffee", 2.55, "medium coffee", 3.05, "large coffee",
			3.55, "bacon roll", 4.53, "orange juice", 3.95);

	public static final Map<String, Double> ADDONS = Map.of("extra milk", 0.32, "foamed milk", 0.51,
			"special roast coffee", 0.95);

	public static final String DELIMETER = "with";
}
