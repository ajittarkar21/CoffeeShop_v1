package com.coffeeshop.model;

public class StampCard {
	Integer beverageOrderedCount;

	public Integer getBeverageOrderedCount() {
		return beverageOrderedCount;
	}

	public void setBeverageOrderedCount(Integer beverageOrderedCount) {
		this.beverageOrderedCount = beverageOrderedCount;
	}

	public StampCard(Integer beverageOrderedCount) {
		this.beverageOrderedCount = beverageOrderedCount;
	}

	@Override
	public String toString() {
		return "StampCard{" + "beverageOrderedCount=" + beverageOrderedCount + '}';
	}
}
