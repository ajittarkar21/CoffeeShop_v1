package com.coffeeshop.model.interfaces;

import com.coffeeshop.model.Addons;

import java.util.List;

public interface MenuItems {
	public String getName();

	public Double getPrice();

	public Boolean isBeverage();

	public List<Addons> getAddons();

	public Boolean isSnacks();
}
