package com.coffeeshop.model;

import java.util.List;

public class CustomerOrder {
	private List<CustomerOrderItem> orderItemList;
	private Integer beverageCount;
	private Integer snacksCount;

	private StampCard stampCard;

	public CustomerOrder(List<CustomerOrderItem> orderItemList, Integer beverageCount, Integer snacksCount,
			StampCard stampCard) {
		this.orderItemList = orderItemList;
		this.beverageCount = beverageCount;
		this.snacksCount = snacksCount;
		this.stampCard = stampCard;
	}

	public List<CustomerOrderItem> getOrderItemList() {
		return orderItemList;
	}

	public void setOrderItemList(List<CustomerOrderItem> orderItemList) {
		this.orderItemList = orderItemList;
	}

	public Integer getBeverageCount() {
		return beverageCount;
	}

	public void setBeverageCount(Integer beverageCount) {
		this.beverageCount = beverageCount;
	}

	public Integer getSnacksCount() {
		return snacksCount;
	}

	public void setSnacksCount(Integer snacksCount) {
		this.snacksCount = snacksCount;
	}

	public StampCard getStampCard() {
		return stampCard;
	}

	public void setStampCard(StampCard stampCard) {
		this.stampCard = stampCard;
	}

	@Override
	public String toString() {
		return "CustomerOrder{" + "orderItemList=" + orderItemList + ", beverageCount=" + beverageCount
				+ ", snacksCount=" + snacksCount + ", stampCard=" + stampCard + '}';
	}
}
