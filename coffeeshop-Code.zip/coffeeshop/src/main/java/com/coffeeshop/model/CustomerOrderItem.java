package com.coffeeshop.model;

import com.coffeeshop.model.interfaces.MenuItems;

import java.util.List;

public class CustomerOrderItem implements MenuItems {
	private String itemPrintName;
	private String name;
	private Double price;
	private List<Addons> addonsList;
	private Boolean isBeverage;
	private Boolean isSnacks;

	public CustomerOrderItem() {
	}

	public CustomerOrderItem(String itemPrintName, String name, Double price, List<Addons> addonsList,
			Boolean isBeverage, Boolean isSnacks) {
		this.itemPrintName = itemPrintName;
		this.name = name;
		this.price = price;
		this.addonsList = addonsList;
		this.isBeverage = isBeverage;
		this.isSnacks = isSnacks;
	}

	public String getItemPrintName() {
		return itemPrintName;
	}

	public void setItemPrintName(String itemPrintName) {
		this.itemPrintName = itemPrintName;
	}

	@Override
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public List<Addons> getAddons() {
		return addonsList;
	}

	public void setAddonsList(List<Addons> addonsList) {
		this.addonsList = addonsList;
	}

	@Override
	public Boolean isBeverage() {
		return isBeverage;
	}

	public void setBeverage(Boolean beverage) {
		isBeverage = beverage;
	}

	@Override
	public Boolean isSnacks() {
		return isSnacks;
	}

	public void setSnacks(Boolean snacks) {
		isSnacks = snacks;
	}

	@Override
	public String toString() {
		return "CustomerOrderItem{" + "itemPrintName='" + itemPrintName + '\'' + ", name='" + name + '\'' + ", price="
				+ price + ", addonsList=" + addonsList + ", isBeverage=" + isBeverage + ", isSnacks=" + isSnacks + '}';
	}
}
