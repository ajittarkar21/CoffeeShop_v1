package com.coffeeshop;

import org.junit.jupiter.api.Test;

import com.coffeeshop.model.StampCard;

import static org.junit.jupiter.api.Assertions.*;

public class StampCardTest {

	@Test
	public void testStampCard() {

		StampCard stampCard = new StampCard(3);

		assertEquals(3, stampCard.getBeverageOrderedCount());
	}

}
