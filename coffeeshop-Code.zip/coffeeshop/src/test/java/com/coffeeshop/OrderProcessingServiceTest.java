package com.coffeeshop;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

import com.coffeeshop.exceptions.CoffeeShopException;
import com.coffeeshop.model.CustomerOrder;
import com.coffeeshop.service.OrderProcessingService;

public class OrderProcessingServiceTest {

	@Test
	public void testProcessOrderRequest() {
		// Given
		OrderProcessingService orderProcessingService = new OrderProcessingService();
		List<String> orderList = Arrays.asList("4", "large coffee with extra milk", "large coffee with extra milk",
				"bacon roll");

		// When
		CustomerOrder customerOrder = null;
		try {
			customerOrder = orderProcessingService.processOrderRequest(orderList);
		} catch (CoffeeShopException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Then
		assertNotNull(customerOrder);
		assertEquals(2, customerOrder.getBeverageCount());
		assertEquals(1, customerOrder.getSnacksCount());
		assertNotNull(customerOrder.getStampCard());
	}

}
