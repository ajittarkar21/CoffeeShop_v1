package com.coffeeshop;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;

import com.coffeeshop.model.Addons;
import com.coffeeshop.model.CustomerOrder;
import com.coffeeshop.model.CustomerOrderItem;
import com.coffeeshop.model.StampCard;
import com.coffeeshop.service.BillProcessingService;

public class BillProcessingServiceTest {

	@Test
	public void testCalculateBillToBePaid() {
		// Given
		BillProcessingService billProcessingService = new BillProcessingService();
		StampCard stampCard = new StampCard(3);

		Addons extraMilk = new Addons("extra milk", 0.32);
		List<Addons> addonsList1 = Arrays.asList(extraMilk);

		// Creating CustomerOrderItems
		CustomerOrderItem item1 = new CustomerOrderItem("large coffee with extra milk", "large coffee", 4.53,
				addonsList1, true, false);
		List<Addons> addonsList = List.of();
		CustomerOrderItem item2 = new CustomerOrderItem("bacon roll", "bacon roll", 4.53, addonsList, false, true); // Assuming
																													// no
																													// addons

		// Creating CustomerOrder
		CustomerOrder customerOrder = new CustomerOrder(Arrays.asList(item1, item2), 1, 1, stampCard);

		// When
		billProcessingService.calculateBillToBePaid(customerOrder);

	}
}
